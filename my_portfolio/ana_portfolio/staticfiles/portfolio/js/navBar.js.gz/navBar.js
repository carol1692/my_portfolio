function activeURL(element){
    console.log(element)
    // document.getElementById(element).classList.add("active","fw-bold")
}


function alertTeste(){
    console.log("TESTE")
    // document.getElementById(element).classList.add("active","fw-bold")
}